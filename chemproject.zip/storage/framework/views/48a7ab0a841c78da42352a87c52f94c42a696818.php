<meta charset="utf-8">
<!-- <link rel="icon" type="image/png" href="https://example.com/favicon.png"/> -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ChemAxe</title>

<!-- Google Font: Source Sans Pro -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<!-- Font Awesome -->
<link rel="stylesheet" href="/plugins/fontawesome-free/css/all.min.css">
<!-- icheck bootstrap -->
<link rel="stylesheet" href="/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="/dist/css/adminlte.min.css">

 <style type="text/css">
    .mytextcolor{
      color: #098BC6 !important;
      font-weight: 600;
    }
  </style><?php /**PATH E:\wamp64\www\chemproject\resources\views/Auth/Layout/auth_header.blade.php ENDPATH**/ ?>