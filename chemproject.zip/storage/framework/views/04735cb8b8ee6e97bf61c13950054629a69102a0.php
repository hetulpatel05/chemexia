<script src="<?php echo e(url('plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(url('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(url('dist/js/adminlte.min.js')); ?>"></script><?php /**PATH E:\wamp64\www\chemproject\resources\views/Auth/Layout/auth_script.blade.php ENDPATH**/ ?>