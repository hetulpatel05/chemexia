

<?php $__env->startSection('breadcrumb'); ?>
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Manage User</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <!-- <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Dashboard v1</li>
        </ol> -->
      </div> <!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
  <div class="card">
   <div class="card-header">
    <div class="row">                       
      <div class="col-md-10">
        <h3 class="card-title">All Users</h3>
      </div>

      <div class="col-md-2">
        <!-- <a href="<?php echo e(url('NewRecord')); ?>" class="btn btn-block btn-outline-primary">Add Record</a> -->
      </div>

    </div>

  </div>
  <!-- /.card-header -->
  <!-- form start -->
  <div class="card-body">
   <table id="tblusers" class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>FullName</th>
        <th>GSTNo</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Created at</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>      
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->gstno); ?></td>
        <td><?php echo e($user->email); ?></td>
        <td><?php echo e($user->phone); ?></td>
        <td><?php echo e(date('d-m-Y', strtotime($user->created_at))); ?></td>
        <td>#</td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">
  $(document).ready(function(){    

    $("#tblusers").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "pagination":true,
      "destroy":true,

    });


  })
</script>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\chemproject\resources\views/allusers.blade.php ENDPATH**/ ?>