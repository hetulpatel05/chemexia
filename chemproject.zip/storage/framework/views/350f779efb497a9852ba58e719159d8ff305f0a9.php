<!DOCTYPE html>
<html lang="en">
<head>
  <?php echo $__env->make('Auth.Layout.auth_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
</head>
<body class="hold-transition login-page">
  <div class="login-box">
    <div class="login-logo">      
      <a href="#" class="mytextcolor">  ChemAxe<b></b></a>
    </div>
    <!-- /.login-logo -->
    <?php echo $__env->yieldContent('content'); ?>
  </div>
  <!-- /.login-box -->

  <!-- jQuery -->
  <?php echo $__env->make('Auth.Layout.auth_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH E:\wamp64\www\chemproject\resources\views/Auth/Layout/AuthMaster.blade.php ENDPATH**/ ?>