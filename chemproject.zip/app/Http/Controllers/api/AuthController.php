<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\Mail;
use JWTAuth;


use App\User;

class AuthController extends Controller
{
    public function login(Request $request)
    {
         $validator =Validator::make($request->all(),
            [
                'email' => 'required',
                'password' => 'required',
            ]);
        if($validator->fails())
        {
            return response()->json([ 'result' => 0, 'message' => 'Validation Error', 'errors' => $validator->errors()->messages()]);
        }
         $credentials = $request->only('email', 'password');

        try{           
            if (! $token = JWTAuth::attempt($credentials)) {                    
                return response()->json(['success' => 0, 'message' => 'Invalid Email or Password'], 200);
            }          
        }
        catch (JWTException $e) {
                // echo $e->getMessage();        
            return response()->json(['success' => '0', 'message' => 'There is something wrong please try again later.'], 200);
        }

        $data['token']=$token;        
        $data['userdata']=Auth::user();

        return response()->json(['success' => 1,'message'=>'Login Successfully','data'=>$data], 200);

    }

   public function registeruser(Request $request)
   {
          $gstno=$request->gstno;
          $phone=$request->phone;
          $email=$request->email;
          $password=bcrypt($request->password);

          $validator = Validator::make($request->all(),
            [
                'gstno' => 'required | max:15|unique:users,gstno',
                'phone' => 'required | numeric',
                'email' => 'required|email|unique:users,email',         
                'password' => 'min:6|required'

            ]);

        if ($validator->fails())
        {
            return response()->json([ 'result' => 0, 'message' => 'Validation Error', 'errors' => $validator->errors()->messages()]);
        }

        $newuser=new User;
        $otpcode = rand(100000,999999);        

        $newuser->gstno=$gstno;
        $newuser->phone=$phone;
        $newuser->email=$email;
        $newuser->password=$password;      
        $newuser->otp=$otpcode;      
        $newuser->save();

        if($newuser==true)
        {

            $verificationcode=[
                'COMPANY_NAME'=>'chemexia',               
                'CODE'=>$otpcode,
                'social_icon'=>'',
            ];

            try
            {
                Mail::send('MailTemplate.verification_code',['verificationcode'=>$verificationcode], function($message) use($email) {
                                    // $message->to($SendMailTo,'cfgcf')->subject('Verification Code');
                    $message->to($email,'Subject')->subject('Verification Code');
                    $message->from('chemexia007@gmail.com', 'chemexia');                                    
                });

                if(Mail::failures())
                {
                    return response()->json(['success'=>0 , 'message'=>'fail to send']);
                }
                         
            }
            catch(\Exception $e)
            {
                echo 'errmsg - '.$e->getMessage();
            }
            return response()->json(['success' => 1,'message'=>'User Registered Successfully'],200);
        }
        else
        {
            return response()->json(['success' => 0,'message'=>'Something Went Wrong PLease try later.']);
        }
   }

   public function verifyotp(Request $request)
   {
            $gstno=$request->gstno;
            $otp=$request->otp;

            $status=1;

            if (User::where('gstno', '=', $gstno)->where('otp',$otp)->exists()) {

                $changestatus=User::where('gstno', $gstno)            
                ->update(['status' => $status]);

                if($changestatus==true)
                {
                    return response()->json(['success'=>1,'message'=>'Account Verified Successfully.']);
                }
                else
                {
                 return response()->json(['success'=>0,'message'=>'Something Went Wrong PLease try Again Later.']);   
             }
         }
         else
         {
            return response()->json(['success'=>0,'message'=>'Verification code is Not Matched']);   
        }
   }
}
