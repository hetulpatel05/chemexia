<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;

class UserController extends Controller
{
    public function __construct()
    {
        // $this->middleware('auth:api', ['except' => ['login']]);
    }
    public function dashboard(Request $request)
    {        
        return view('dashboard');
    }

    public function showusers($value='')
    {
        // $users=User::where('role','!=','admin')->get();
        $users=User::all();
        return view('allusers',compact('users'));
    }
}
