@extends('layout.master')

@section('breadcrumb')
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Berichten</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <!-- <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Dashboard v1</li>
        </ol> -->
      </div> <!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
@endsection

@section('content')
<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Berichten</h3>
      </div>
      <!-- ./card-header -->
      <div class="card-body p-0">
        <table class="table table-hover">
          <tbody>
            <tr>
              <td class="border-0">
              <i class="expandable-table-caret fas fa-caret-right fa-fw"></i>
              Sport2000
            </td>
            </tr>
            <tr data-widget="expandable-table" aria-expanded="true">
              <td>
                <i class="expandable-table-caret fas fa-caret-right fa-fw"></i>
                Sport2000
              </td>
            </tr>
            <tr class="expandable-body">
              <td>
                <div class="p-0">
                  <table class="table table-hover">
                    <tbody>
                      <tr data-widget="expandable-table" aria-expanded="false">
                        <td>
                          <i class="expandable-table-caret fas fa-caret-right fa-fw"></i>
                          219-1
                        </td>
                      </tr>
                      <tr class="expandable-body">
                        <td>
                          <div class="p-0">
                            <table class="table table-hover">
                              <tbody>
                                <tr>
                                  <td>219-1-1</td>
                                </tr>
                                <tr>
                                  <td>219-1-2</td>
                                </tr>
                                <tr>
                                  <td>219-1-3</td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </td>
                      </tr>
                      <tr data-widget="expandable-table" aria-expanded="false">
                        <td>
                          <button type="button" class="btn btn-primary p-0">
                            <i class="expandable-table-caret fas fa-caret-right fa-fw"></i>
                          </button>
                          219-2
                        </td>
                      </tr>
                      <tr class="expandable-body">
                        <td>
                          <div class="p-0">
                            <table class="table table-hover">
                              <tbody>
                                <tr>
                                  <td>219-2-1</td>
                                </tr>
                                <tr>
                                  <td>219-2-2</td>
                                </tr>
                                <tr>
                                  <td>Auping</td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>219-3</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </td>
            </tr>
            <tr>
              <td><i class="expandable-table-caret fas fa-caret-right fa-fw"></i>Sport2000</td>
            </tr>
            <tr>
              <td><i class="expandable-table-caret fas fa-caret-right fa-fw"></i>Auping</td>
            </tr>
            <tr>
              <td><i class="expandable-table-caret fas fa-caret-right fa-fw"></i>Auping</td>
            </tr>
            <tr>
              <td><i class="expandable-table-caret fas fa-caret-right fa-fw"></i>Sport2000</td>
            </tr>
            <tr>
              <td><i class="expandable-table-caret fas fa-caret-right fa-fw"></i>Auping</td>
            </tr>
            <tr>
              <td><i class="expandable-table-caret fas fa-caret-right fa-fw"></i>Auping</td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>
</div>

@endsection
@include('layout.script')
<script type="text/javascript">
  $(document).ready(function(){    

    $("#tblusers").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "pagination":true,
      "destroy":true,

    });


  })
</script>